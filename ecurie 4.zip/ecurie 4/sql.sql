CREATE TABLE IF NOT EXISTS horses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(50),
    model VARCHAR(100),
    name VARCHAR(100),
    race VARCHAR(50),
    handling VARCHAR(20),
    is_favorite TINYINT DEFAULT 0
);
