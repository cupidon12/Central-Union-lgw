--------------------------------------------------
-- PREVIEW.LUA — PREVIEW CHEVAL (VORP FINAL CLEAN)
--------------------------------------------------

Preview = {}

local previewHorse = nil
local previewCam = nil

-- Lumière showroom
local previewLightActive = false
local previewLightCoords = nil

--------------------------------------------------
-- CLEAR PREVIEW
--------------------------------------------------

function Preview.Clear()
    previewLightActive = false
    previewLightCoords = nil

    if previewHorse and DoesEntityExist(previewHorse) then
        DeleteEntity(previewHorse)
        previewHorse = nil
    end

    if previewCam then
        RenderScriptCams(false, true, 300, true, true)
        DestroyCam(previewCam, false)
        previewCam = nil
    end

    -- sortir de l’instance
    TriggerEvent("vorp:setInstancePlayer", false)
end

--------------------------------------------------
-- LUMIÈRE PREVIEW (SHOWROOM, COMME VORP)
--------------------------------------------------

CreateThread(function()
    while true do
        if previewLightActive and previewLightCoords then
            DrawLightWithRange(
                previewLightCoords.x,
                previewLightCoords.y,
                previewLightCoords.z + 2.2, -- hauteur
                255, 255, 255,              -- couleur
                10.0,                       -- portée
                15.0                        -- intensité
            )
            Wait(0)
        else
            Wait(300)
        end
    end
end)

--------------------------------------------------
-- SPAWN PREVIEW HORSE
--------------------------------------------------

function Preview.SpawnHorse(stable, model)
    Preview.Clear()
    if not stable or not model then return end

    local s = stable.SpawnHorse
    local c = stable.CamHorse

    -- entrer dans l’instance (comme VORP)
    TriggerEvent("vorp:setInstancePlayer", true)

    local hash = GetHashKey(model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(0) end

    previewHorse = CreatePed(
        hash,
        s[1], s[2], s[3],
        s[4],
        false, true, true, true
    )

    if not DoesEntityExist(previewHorse) then
        print("^1[VORP_ECURIE] Erreur spawn preview cheval :", model, "^0")
        return
    end

    --------------------------------------------------
    -- ORDRE CRITIQUE (IDENTIQUE VORP_STABLES)
    --------------------------------------------------

    Citizen.InvokeNative(0x283978A15512B2FE, previewHorse, true)
    Citizen.InvokeNative(0xC8A9481A01E63C28, previewHorse, 1)
    Citizen.InvokeNative(0xCC8CA3E88256E58F, previewHorse, 0, 1, 1, 1, 0)

    --------------------------------------------------
    -- 🧼 NETTOYAGE TOTAL (FIX SALISSURE DÉFINITIF)
    --------------------------------------------------

    ClearPedBloodDamage(previewHorse)
    ClearPedEnvDirt(previewHorse)
    ClearPedDamageDecalByZone(previewHorse, 10, "ALL")

    Citizen.InvokeNative(0x6585D955A68452A5, previewHorse)      -- reset visible damage
    Citizen.InvokeNative(0x8FE22675A5A45817, previewHorse, 0.0) -- FORCE DIRT LEVEL = 0 (CRITIQUE)

    --------------------------------------------------
    -- SÉCURITÉ
    --------------------------------------------------

    FreezeEntityPosition(previewHorse, true)
    SetEntityInvincible(previewHorse, true)
    SetBlockingOfNonTemporaryEvents(previewHorse, true)

    --------------------------------------------------
    -- LUMIÈRE SHOWROOM
    --------------------------------------------------

    previewLightCoords = vector3(s[1], s[2], s[3])
    previewLightActive = true

    --------------------------------------------------
    -- CAMÉRA FIXE (VORP)
    --------------------------------------------------

    previewCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(previewCam, c[1], c[2], c[3])
    SetCamRot(previewCam, c[4], c[5], c[6], 2)
    SetCamActive(previewCam, true)
    RenderScriptCams(true, true, 300, true, true)
end
