local uiOpen = false

RegisterNetEvent("vorp_ecuries:openStableUI")
AddEventHandler("vorp_ecuries:openStableUI", function()
    if uiOpen then return end
    uiOpen = true
    SetNuiFocus(true, true)

    SendNUIMessage({
        action = "openStable"
    })
end)

RegisterNetEvent("vorp_ecuries:openBuyMenu")
AddEventHandler("vorp_ecuries:openBuyMenu", function(races)
    SendNUIMessage({
        action = "openBuyMenu",
        races = races
    })
end)

RegisterNUICallback("close", function(_, cb)
    uiOpen = false
    SetNuiFocus(false, false)
    cb("ok")
end)
