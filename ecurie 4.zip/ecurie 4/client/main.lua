local isNearStable = false

CreateThread(function()
    while true do
        Wait(0)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        isNearStable = false

        for _, stable in pairs(Config.Stables) do
            local sx, sy, sz, dist = table.unpack(stable.EnterStable)
            local distance = #(coords - vector3(sx, sy, sz))

            if distance < dist then
                isNearStable = true

                -- Indication (optionnel)
                DrawTxt("Appuyez sur [J] pour ouvrir l’écurie", 0.5, 0.9)

                if IsControlJustPressed(0, Config.OpenStableKey) then
                    TriggerEvent("vorp_ecuries:openStableUI")
                    Wait(1000) -- anti-spam
                end
                break
            end
        end
    end
end)

-- Texte simple à l’écran
function DrawTxt(text, x, y)
    SetTextScale(0.35, 0.35)
    SetTextFontForCurrentCommand(1)
    SetTextCentre(true)
    DisplayText(CreateVarString(10, "LITERAL_STRING", text), x, y)
end
