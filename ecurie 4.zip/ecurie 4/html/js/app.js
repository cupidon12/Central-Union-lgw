const Menu = {
    opened: false,

    // MAIN_CATEGORY | HORSE_CATEGORY | BUY_RACE | BUY_VARIATION
    state: "MAIN_CATEGORY",

    index: 0,
    variationIndex: 0,

    races: [],
    selectedRace: null
};

// ===============================
// OPEN UI
// ===============================
window.addEventListener("message", function (event) {

    if (event.data.action === "openStable") {
        Menu.opened = true;
        Menu.state = "MAIN_CATEGORY";
        Menu.index = 0;
        render();
    }

    if (event.data.action === "openBuyMenu") {
        Menu.races = event.data.races || [];
        Menu.state = "BUY_RACE";
        Menu.index = 0;
        render();
        scrollSelected();
    }
});

// ===============================
// RENDER
// ===============================
function render() {
    if (!Menu.opened) return;

    let html = `
    <div class="menu align-top-left">
        <div class="head">ÉCURIE</div>
        <div class="desciptions">${getSubtitle()}</div>
        <div class="topline"></div>
    `;

    // MENU PRINCIPAL
    if (Menu.state === "MAIN_CATEGORY") {
        html += renderList(["Gestion des chevaux", "Gestion des charrettes"]);
    }

    // GESTION CHEVAUX
    if (Menu.state === "HORSE_CATEGORY") {
        html += renderList(["Acheter un cheval", "Mes chevaux"]);
    }

    // ACHAT - RACES
    if (Menu.state === "BUY_RACE") {
        html += `
        <div class="menu-items">
            ${Menu.races.map((r, i) => `
                <div class="menu-item ${i === Menu.index ? "selected" : ""}">
                    ${r.race}
                </div>
            `).join("")}
        </div>`;
    }

    // ACHAT - VARIATIONS
    if (Menu.state === "BUY_VARIATION") {
        const race = Menu.selectedRace;
        const v = race.variations[Menu.variationIndex];

        html += `
        <div class="menu-items">
            ${race.variations.map((va, i) => `
                <div class="menu-item ${i === Menu.variationIndex ? "selected" : ""}">
                    ${va.label}
                </div>
            `).join("")}
        </div>

        <div class="horse-stats">
            <div class="stat">
                <span>Vitesse</span>
                <div class="bar"><div class="fill" style="width:${v.speed * 20}%"></div></div>
            </div>

            <div class="stat">
                <span>Accélération</span>
                <div class="bar"><div class="fill" style="width:${v.acceleration * 20}%"></div></div>
            </div>

            <div class="stat">
                <span>Maniabilité</span>
                <span class="handling ${race.handling}">${race.handling}</span>
            </div>
        </div>

        <div class="horse-price">
            <span>PRIX</span>
            <span>$${v.price}</span>
        </div>
        `;
    }

    html += `<div class="footer-text">${getFooter()}</div></div>`;
    document.getElementById("menus").innerHTML = html;
}

// ===============================
// LIST HELPER
// ===============================
function renderList(items) {
    return `
    <div class="menu-items">
        ${items.map((t, i) => `
            <div class="menu-item ${i === Menu.index ? "selected" : ""}">
                ${t}
            </div>
        `).join("")}
    </div>`;
}

// ===============================
// TEXTES
// ===============================
function getSubtitle() {
    if (Menu.state === "MAIN_CATEGORY") return "Menu principal";
    if (Menu.state === "HORSE_CATEGORY") return "Gestion des chevaux";
    if (Menu.state === "BUY_RACE") return "Choisissez une race";
    if (Menu.state === "BUY_VARIATION") return Menu.selectedRace.race;
    return "";
}

function getFooter() {
    if (Menu.state === "BUY_RACE") return "Entrée : voir les variations";
    if (Menu.state === "BUY_VARIATION") return "Entrée : acheter ce cheval";
    return "Entrée : sélectionner";
}

// ===============================
// INPUT
// ===============================
document.addEventListener("keydown", function (e) {
    if (!Menu.opened) return;

    const max = () => {
        if (Menu.state === "MAIN_CATEGORY") return 2;
        if (Menu.state === "HORSE_CATEGORY") return 2;
        if (Menu.state === "BUY_RACE") return Menu.races.length;
        if (Menu.state === "BUY_VARIATION") return Menu.selectedRace.variations.length;
        return 1;
    };

    if (e.key === "ArrowUp") move(-1, max());
    if (e.key === "ArrowDown") move(1, max());
    if (e.key === "Enter") enter();
    if (e.key === "Backspace") back();
    if (e.key === "Escape") closeMenu();
});

// ===============================
// NAVIGATION
// ===============================
function move(dir, max) {
    if (Menu.state === "BUY_VARIATION")
        Menu.variationIndex = (Menu.variationIndex + dir + max) % max;
    else
        Menu.index = (Menu.index + dir + max) % max;

    render();
    scrollSelected();
}

function enter() {

    if (Menu.state === "MAIN_CATEGORY" && Menu.index === 0) {
        Menu.state = "HORSE_CATEGORY";
        Menu.index = 0;
        render();
        return;
    }

    if (Menu.state === "HORSE_CATEGORY" && Menu.index === 0) {
        // ✅ CORRECTION ICI
        fetch(`https://${GetParentResourceName()}/getBuyHorses`, {
            method: "POST"
        });
        return;
    }

    if (Menu.state === "BUY_RACE") {
        Menu.selectedRace = Menu.races[Menu.index];
        Menu.variationIndex = 0;
        Menu.state = "BUY_VARIATION";
        render();
        return;
    }

    if (Menu.state === "BUY_VARIATION") {
        const v = Menu.selectedRace.variations[Menu.variationIndex];
        fetch(`https://${GetParentResourceName()}/buyHorse`, {
            method: "POST",
            body: JSON.stringify(v)
        });
    }
}

function back() {
    if (Menu.state === "BUY_VARIATION") Menu.state = "BUY_RACE";
    else if (Menu.state === "BUY_RACE") Menu.state = "HORSE_CATEGORY";
    else if (Menu.state === "HORSE_CATEGORY") Menu.state = "MAIN_CATEGORY";
    else closeMenu();

    Menu.index = 0;
    render();
}

// ===============================
// SCROLL AUTO
// ===============================
function scrollSelected() {
    requestAnimationFrame(() => {
        const c = document.querySelector(".menu-items");
        const s = document.querySelector(".menu-item.selected");
        if (!c || !s) return;

        if (s.offsetTop < c.scrollTop)
            c.scrollTop = s.offsetTop;
        else if (s.offsetTop + s.offsetHeight > c.scrollTop + c.clientHeight)
            c.scrollTop = s.offsetTop + s.offsetHeight - c.clientHeight;
    });
}

// ===============================
// CLOSE
// ===============================
function closeMenu() {
    Menu.opened = false;
    document.getElementById("menus").innerHTML = "";
    fetch(`https://${GetParentResourceName()}/close`, { method: "POST" });
}
