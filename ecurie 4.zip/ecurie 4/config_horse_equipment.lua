Config = Config or {}

Config.HorseEquipment = {

    saddle = {
        label = "Selles",
        components = {
            { label = "Selle western simple", hash = 0xBAA7E618, price = 15 },
            { label = "Selle chasseur",       hash = 0xC6B1F11D, price = 30 },
            { label = "Selle élégante",       hash = 0x3F0F4E46, price = 45 },
        }
    },

    mane = {
        label = "Crinière",
        components = {
            { label = "Crinière courte", hash = 0x864B03AE, price = 5 },
            { label = "Crinière longue", hash = 0xB13E3A9A, price = 5 },
        }
    },

    tail = {
        label = "Queue",
        components = {
            { label = "Queue courte", hash = 0xA63B03F5, price = 5 },
            { label = "Queue longue", hash = 0xE7E2B88C, price = 5 },
        }
    }
}



--------------------------------------------------
-- HORSE TACKS (VORP-STABLES STYLE)
--------------------------------------------------

Config.HorseTacks = {
    {
        label = "Selle simple",
        hash = 0xF36C1A65, -- tack default Rockstar (universel)
        price = 50
    },
    {
        label = "Selle western",
        hash = 0xBAA7E618,
        price = 120
    }
}
