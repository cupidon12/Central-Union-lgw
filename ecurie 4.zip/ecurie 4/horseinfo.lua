--------------------------------------------------
-- HORSEINFO.LUA — RACES + VARIATIONS + STATS
-- Compatible avec UI RDR2 (Race -> Variation -> Stats -> Buy)
--
-- Champs:
--  handling: "Heavy" | "Standard" | "Race"
--  variations: { label, model, price, speed(1-5), acceleration(1-5) }
--------------------------------------------------

HorseInfo = {

-- ==================================================
-- ARABIAN
-- ==================================================
["Arabian"] = {
    handling = "Race",
    variations = {
        { label = "Black",           model = "A_C_Horse_Arabian_Black",            price = 500, speed = 5, acceleration = 5 },
        { label = "White",           model = "A_C_Horse_Arabian_White",            price = 600, speed = 5, acceleration = 5 },
        { label = "Red Chestnut",    model = "A_C_Horse_Arabian_RedChestnut",      price = 450, speed = 5, acceleration = 4 },
        { label = "Rose Grey Bay",   model = "A_C_Horse_Arabian_RoseGreyBay",      price = 650, speed = 5, acceleration = 5 },
        { label = "Warped Brindle",  model = "A_C_Horse_Arabian_WarpedBrindle_PC", price = 700, speed = 5, acceleration = 5 },
    }
},

-- ==================================================
-- AMERICAN STANDARDBRED
-- ==================================================
["American Standardbred"] = {
    handling = "Standard",
    variations = {
        { label = "Black",               model = "A_C_Horse_AmericanStandardbred_Black",               price = 120, speed = 3, acceleration = 3 },
        { label = "Buckskin",            model = "A_C_Horse_AmericanStandardbred_Buckskin",            price = 120, speed = 3, acceleration = 3 },
        { label = "Light Buckskin",      model = "A_C_Horse_AmericanStandardbred_Lightbuckskin",      price = 130, speed = 3, acceleration = 3 },
        { label = "Palomino Dapple",     model = "A_C_Horse_AmericanStandardbred_PalominoDapple",     price = 140, speed = 3, acceleration = 4 },
        { label = "Silver Tail Buckskin",model = "A_C_Horse_AmericanStandardbred_SilverTailBuckskin", price = 150, speed = 4, acceleration = 3 },
    }
},

-- ==================================================
-- APPALOOSA
-- ==================================================
["Appaloosa"] = {
    handling = "Standard",
    variations = {
        { label = "Black Snowflake",  model = "A_C_Horse_Appaloosa_BlackSnowflake",  price = 120, speed = 3, acceleration = 3 },
        { label = "Blanket",          model = "A_C_Horse_Appaloosa_Blanket",         price = 120, speed = 3, acceleration = 3 },
        { label = "Brown Leopard",    model = "A_C_Horse_Appaloosa_BrownLeopard",    price = 130, speed = 3, acceleration = 4 },
        { label = "Leopard",          model = "A_C_Horse_Appaloosa_Leopard",         price = 130, speed = 3, acceleration = 4 },
        { label = "Leopard Blanket",  model = "A_C_Horse_Appaloosa_LeopardBlanket",  price = 140, speed = 4, acceleration = 3 },
    }
},

-- ==================================================
-- ARDENNES
-- ==================================================
["Ardennes"] = {
    handling = "Heavy",
    variations = {
        { label = "Bay Roan",        model = "A_C_Horse_Ardennes_BayRoan",        price = 160, speed = 2, acceleration = 2 },
        { label = "Iron Grey Roan",  model = "A_C_Horse_Ardennes_IronGreyRoan",  price = 170, speed = 2, acceleration = 2 },
        { label = "Strawberry Roan", model = "A_C_Horse_Ardennes_StrawberryRoan",price = 180, speed = 2, acceleration = 3 },
    }
},

-- ==================================================
-- BELGIAN
-- ==================================================
["Belgian"] = {
    handling = "Heavy",
    variations = {
        { label = "Blond Chestnut", model = "A_C_Horse_Belgian_BlondChestnut",  price = 140, speed = 2, acceleration = 2 },
        { label = "Mealy Chestnut", model = "A_C_Horse_Belgian_MealyChestnut",  price = 140, speed = 2, acceleration = 2 },
    }
},

-- ==================================================
-- BRETON (Bounty Hunter - Online)
-- ==================================================
["Breton"] = {
    handling = "Heavy",
    variations = {
        { label = "Grullo Dun",   model = "A_C_Horse_Breton_GrulloDun",  price = 220, speed = 4, acceleration = 3 },
        { label = "Red Roan",     model = "A_C_Horse_Breton_RedRoan",    price = 220, speed = 4, acceleration = 3 },
        { label = "Seal Brown",   model = "A_C_Horse_Breton_SealBrown",  price = 240, speed = 4, acceleration = 4 },
        { label = "Sorrel",       model = "A_C_Horse_Breton_Sorrel",     price = 220, speed = 4, acceleration = 3 },
        { label = "Steel Grey",   model = "A_C_Horse_Breton_SteelGrey",  price = 240, speed = 4, acceleration = 4 },
    }
},

-- ==================================================
-- CRIOLLO (Collector - Online)
-- ==================================================
["Criollo"] = {
    handling = "Race",
    variations = {
        { label = "Dun",            model = "A_C_Horse_Criollo_Dun",            price = 230, speed = 4, acceleration = 4 },
        { label = "Marble Sabino",  model = "A_C_Horse_Criollo_MarbleSabino",   price = 260, speed = 4, acceleration = 5 },
        { label = "Bay Brindle",    model = "A_C_Horse_Criollo_BayBrindle",     price = 260, speed = 4, acceleration = 5 },
        { label = "Sorrel Overo",   model = "A_C_Horse_Criollo_SorrelOvero",    price = 240, speed = 4, acceleration = 4 },
    }
},

-- ==================================================
-- DUTCH WARMBLOOD
-- ==================================================
["Dutch Warmblood"] = {
    handling = "Standard",
    variations = {
        { label = "Chocolate Roan", model = "A_C_Horse_DutchWarmblood_ChocolateRoan", price = 180, speed = 3, acceleration = 3 },
        { label = "Seal Brown",     model = "A_C_Horse_DutchWarmblood_SealBrown",     price = 180, speed = 3, acceleration = 3 },
        { label = "Sooty Buckskin", model = "A_C_Horse_DutchWarmblood_SootyBuckskin", price = 190, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- GYPSY COB (Naturalist - Online)
-- ==================================================
["Gypsy Cob"] = {
    handling = "Heavy",
    variations = {
        { label = "Palomino Blagdon", model = "A_C_Horse_GypsyCob_PalominoBlagdon", price = 240, speed = 3, acceleration = 3 },
        { label = "Piebald",          model = "A_C_Horse_GypsyCob_Piebald",         price = 240, speed = 3, acceleration = 3 },
        { label = "Splashed Bay",     model = "A_C_Horse_GypsyCob_SplashedBay",     price = 260, speed = 3, acceleration = 4 },
        { label = "Skewbald",         model = "A_C_Horse_GypsyCob_Skewbald",        price = 260, speed = 3, acceleration = 4 },
        { label = "White Blagdon",    model = "A_C_Horse_GypsyCob_WhiteBlagdon",    price = 270, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- HUNGARIAN HALFBRED
-- ==================================================
["Hungarian Halfbred"] = {
    handling = "Standard",
    variations = {
        { label = "Dark Dapple Grey",  model = "A_C_Horse_HungarianHalfbred_DarkDappleGrey",  price = 160, speed = 3, acceleration = 3 },
        { label = "Flaxen Chestnut",   model = "A_C_Horse_HungarianHalfbred_FlaxenChestnut",  price = 160, speed = 3, acceleration = 3 },
        { label = "Piebald Tobiano",   model = "A_C_Horse_HungarianHalfbred_PiebaldTobiano",  price = 170, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- KENTUCKY SADDLE
-- ==================================================
["Kentucky Saddler"] = {
    handling = "Standard",
    variations = {
        { label = "Black",           model = "A_C_Horse_KentuckySaddle_Black",                price = 110, speed = 3, acceleration = 3 },
        { label = "Grey",            model = "A_C_Horse_KentuckySaddle_Grey",                 price = 110, speed = 3, acceleration = 3 },
        { label = "Silver Bay",      model = "A_C_Horse_KentuckySaddle_SilverBay",           price = 120, speed = 3, acceleration = 3 },
        { label = "Chestnut Pinto",  model = "A_C_Horse_KentuckySaddle_ChestnutPinto",       price = 120, speed = 3, acceleration = 3 },
        { label = "Buttermilk Buckskin", model = "A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC", price = 130, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- KLADRUBER (Trader - Online)
-- ==================================================
["Kladruber"] = {
    handling = "Standard",
    variations = {
        { label = "Black",    model = "A_C_Horse_Kladruber_Black",    price = 220, speed = 3, acceleration = 3 },
        { label = "Silver",   model = "A_C_Horse_Kladruber_Silver",   price = 230, speed = 3, acceleration = 4 },
        { label = "Cremello", model = "A_C_Horse_Kladruber_Cremello", price = 240, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- MISSOURI FOX TROTTER
-- ==================================================
["Missouri Fox Trotter"] = {
    handling = "Race",
    variations = {
        { label = "Amber Champagne",      model = "A_C_Horse_MissouriFoxTrotter_AmberChampagne",      price = 300, speed = 5, acceleration = 4 },
        { label = "Silver Dapple Pinto",  model = "A_C_Horse_MissouriFoxTrotter_SilverDapplePinto",   price = 320, speed = 5, acceleration = 4 },
    }
},

-- ==================================================
-- MORGAN
-- ==================================================
["Morgan"] = {
    handling = "Standard",
    variations = {
        { label = "Flaxen Chestnut", model = "A_C_Horse_Morgan_FlaxenChestnut",  price = 100, speed = 2, acceleration = 2 },
        { label = "Liver Chestnut",  model = "A_C_Horse_Morgan_LiverChestnut_PC",price = 110, speed = 2, acceleration = 2 },
        { label = "Bay",             model = "A_C_Horse_Morgan_Bay",             price = 100, speed = 2, acceleration = 2 },
        { label = "Palomino",        model = "A_C_Horse_Morgan_Palomino",        price = 110, speed = 2, acceleration = 3 },
    }
},

-- ==================================================
-- MUSTANG
-- ==================================================
["Mustang"] = {
    handling = "Standard",
    variations = {
        { label = "Black Overo", model = "A_C_Horse_Mustang_BlackOvero", price = 180, speed = 3, acceleration = 3 },
        { label = "Golden Dun",  model = "A_C_Horse_Mustang_GoldenDun",  price = 180, speed = 3, acceleration = 3 },
        { label = "Grullo Dun",  model = "A_C_Horse_Mustang_GrulloDun",  price = 190, speed = 3, acceleration = 4 },
        { label = "Wild Bay",    model = "A_C_Horse_Mustang_WildBay",    price = 190, speed = 3, acceleration = 4 },
    }
},

-- ==================================================
-- NAKOTA
-- ==================================================
["Nokota"] = {
    handling = "Race",
    variations = {
        { label = "Blue Roan",     model = "A_C_Horse_Nokota_BlueRoan",     price = 160, speed = 4, acceleration = 4 },
        { label = "Reverse Dapple",model = "A_C_Horse_Nokota_ReverseDappleRoan", price = 170, speed = 4, acceleration = 4 },
        { label = "White Roan",    model = "A_C_Horse_Nokota_WhiteRoan",    price = 170, speed = 4, acceleration = 4 },
    }
},

-- ==================================================
-- NORFOLK ROADSTER (Moonshiner - Online)
-- ==================================================
["Norfolk Roadster"] = {
    handling = "Race",
    variations = {
        { label = "Rose Grey",        model = "A_C_Horse_NorfolkRoadster_RoseGrey",        price = 260, speed = 4, acceleration = 4 },
        { label = "Speckled Grey",    model = "A_C_Horse_NorfolkRoadster_SpeckledGrey",    price = 270, speed = 4, acceleration = 5 },
        { label = "Spotted Tricolor", model = "A_C_Horse_NorfolkRoadster_SpottedTricolor", price = 270, speed = 4, acceleration = 5 },
    }
},

-- ==================================================
-- SHIRE
-- ==================================================
["Shire"] = {
    handling = "Heavy",
    variations = {
        { label = "Dark Bay",    model = "A_C_Horse_Shire_DarkBay",    price = 150, speed = 2, acceleration = 2 },
        { label = "Light Grey",  model = "A_C_Horse_Shire_LightGrey",  price = 150, speed = 2, acceleration = 2 },
        { label = "Raven Black", model = "A_C_Horse_Shire_RavenBlack", price = 160, speed = 2, acceleration = 2 },
    }
},

-- ==================================================
-- SUFFOLK PUNCH
-- ==================================================
["Suffolk Punch"] = {
    handling = "Heavy",
    variations = {
        { label = "Sorrel", model = "A_C_Horse_SuffolkPunch_Sorrel", price = 140, speed = 2, acceleration = 2 },
        { label = "Red Chestnut", model = "A_C_Horse_SuffolkPunch_RedChestnut", price = 150, speed = 2, acceleration = 2 },
    }
},

-- ==================================================
-- TENNESSEE WALKER
-- ==================================================
["Tennessee Walker"] = {
    handling = "Standard",
    variations = {
        { label = "Black Rabicano", model = "A_C_Horse_TennesseeWalker_BlackRabicano", price = 100, speed = 2, acceleration = 2 },
        { label = "Chestnut",       model = "A_C_Horse_TennesseeWalker_Chestnut",      price = 90,  speed = 2, acceleration = 2 },
        { label = "Mahogany Bay",   model = "A_C_Horse_TennesseeWalker_MahoganyBay",  price = 100, speed = 2, acceleration = 2 },
        { label = "Red Roan",       model = "A_C_Horse_TennesseeWalker_RedRoan",      price = 100, speed = 2, acceleration = 2 },
    }
},

-- ==================================================
-- THOROUGHBRED
-- ==================================================
["Thoroughbred"] = {
    handling = "Race",
    variations = {
        { label = "Brindle",        model = "A_C_Horse_Thoroughbred_Brindle",        price = 260, speed = 5, acceleration = 4 },
        { label = "Blood Bay",      model = "A_C_Horse_Thoroughbred_BloodBay",      price = 240, speed = 5, acceleration = 4 },
        { label = "Dapple Grey",    model = "A_C_Horse_Thoroughbred_DappleGrey",    price = 250, speed = 5, acceleration = 4 },
        { label = "Black Chestnut", model = "A_C_Horse_Thoroughbred_BlackChestnut", price = 240, speed = 5, acceleration = 4 },
    }
},

-- ==================================================
-- TURKOMAN
-- ==================================================
["Turkoman"] = {
    handling = "Race",
    variations = {
        { label = "Dark Bay", model = "A_C_Horse_Turkoman_DarkBay", price = 280, speed = 4, acceleration = 4 },
        { label = "Gold",     model = "A_C_Horse_Turkoman_Gold",    price = 300, speed = 4, acceleration = 4 },
        { label = "Silver",   model = "A_C_Horse_Turkoman_Silver",  price = 300, speed = 4, acceleration = 4 },
    }
},

-- ==================================================
-- MULE / DONKEY
-- ==================================================
["Other"] = {
    handling = "Heavy",
    variations = {
        { label = "Mule",   model = "A_C_HorseMule_01", price = 80, speed = 1, acceleration = 1 },
        { label = "Donkey", model = "A_C_Donkey_01",    price = 60, speed = 1, acceleration = 1 },
    }
},

}
