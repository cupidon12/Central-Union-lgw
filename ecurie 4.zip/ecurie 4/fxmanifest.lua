fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'


author 'Bill'
description 'Farm Animal Breeding for VORP & vorp_inventory 4.4'

-- ======================
-- SHARED
-- ======================
shared_scripts {
    'horseinfo.lua',
    'config.lua',
    'config_horse_equipment.lua'
}

-- ======================
-- CLIENT
-- ======================
client_scripts {
    'client/main.lua',
    'client/preview.lua',
    'client/stable_ui.lua'
}

-- ======================
-- SERVER
-- ======================
server_scripts {
    '@oxmysql/lib/MySQL.lua',

    'server/horse_buy.lua',
    'server/horse_list.lua',
    'server/horse_spawn.lua',
    'server/horse_rename.lua',
    'server/horse_default.lua',
    'server/horse_groom.lua',
    'server/horse_inventory.lua',
    'server/horse_equipment.lua',
    'server/horse_ui.lua',
    'server/horse_manage.lua' -- 👈 AJOUT ICI
}

-- ======================
-- UI (NUI)
-- ======================
ui_page 'html/ui.html'

files {
    -- HTML
    'html/ui.html',

    -- JS
    'html/js/app.js',
    'html/js/mustache.min.js',

    -- CSS
    'html/css/app.css',

    -- IMAGES UI (OBLIGATOIRE POUR TON MENU)
    'html/css/*.png',
    'html/css/*.jpg',
    'html/css/*.jpeg',

    -- FONTS
    'html/fonts/*.ttf',
    'html/fonts/*.otf',
    'html/fonts/*.woff',
    'html/fonts/*.woff2'
}