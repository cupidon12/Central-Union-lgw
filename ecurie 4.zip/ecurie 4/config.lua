--------------------------------------------------
-- CONFIG.LUA — VORP_ECURIE (SIMPLE & STABLE)
--------------------------------------------------

Config = {}

--------------------------------------------------
-- GLOBAL
--------------------------------------------------
Config.DevMode = true
Config.MaxHorses = 3

--------------------------------------------------
-- TOUCHES
--------------------------------------------------
Config.OpenStableKey = 0xF3830D8E -- J

--------------------------------------------------
-- DISTANCES
--------------------------------------------------
Config.OpenDistance = 2.0

--------------------------------------------------
-- STABLES
--------------------------------------------------
Config.Stables = {

    {
        Name = "Ecurie de Valentine",

        EnterStable = { -365.87, 789.51, 116.17, 2.0 },
        SpawnHorse  = { -366.07, 781.81, 115.14, 5.97 },

        horses = {
            A_C_Horse_AmericanStandardbred_Black = 100,
            A_C_Horse_AmericanStandardbred_Buckskin = 100,
            A_C_Horse_Morgan_FlaxenChestnut = 100,
            A_C_Horse_Breton_RedRoan = 100,
            A_C_Horse_Turkoman_Gold = 100
        }
    }

}
