RegisterServerEvent("vorp_ecuries:openHorseInventory")
AddEventHandler("vorp_ecuries:openHorseInventory", function()
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        local horse = exports.oxmysql:executeSync(
            "SELECT id, inventory_id FROM player_horses WHERE charidentifier = ? AND is_default = 1 LIMIT 1",
            { Character.charIdentifier }
        )

        if not horse or not horse[1] then
            TriggerClientEvent("vorp:TipRight", _source, "? Aucun cheval actif", 4000)
            return
        end

        local inventoryId = horse[1].inventory_id

        -- cr�er la sacoche si inexistante
        if not inventoryId then
            inventoryId = "horse_" .. horse[1].id

            exports.oxmysql:update(
                "UPDATE player_horses SET inventory_id = ? WHERE id = ?",
                { inventoryId, horse[1].id }
            )
        end

        -- ouvrir l'inventaire (VORP INVENTORY)
        TriggerEvent(
            "vorp_inventory:openInventory",
            _source,
            inventoryId,
            "Sacoche du cheval",
            30 -- slots
        )
    end)
end)
