RegisterServerEvent("vorp_ecuries:buyHorse")
AddEventHandler("vorp_ecuries:buyHorse", function(model, price)
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        -- argent
        if Character.money < price then
            TriggerClientEvent("vorp:TipRight", _source, "❌ Pas assez d'argent", 4000)
            return
        end

        -- limite chevaux
        local count = exports.oxmysql:scalarSync(
            "SELECT COUNT(*) FROM player_horses WHERE charidentifier = ?",
            { Character.charIdentifier }
        )

        if count >= Config.MaxHorses then
            TriggerClientEvent(
                "vorp:TipRight",
                _source,
                "❌ Limite de chevaux atteinte",
                4000
            )
            return
        end

        -- retirer argent
        Character.removeCurrency(0, price)

        -- sauvegarde SQL
        exports.oxmysql:insert(
            [[
                INSERT INTO player_horses
                (charidentifier, model, name, health, stamina)
                VALUES (?, ?, ?, ?, ?)
            ]],
            {
                Character.charIdentifier,
                model,
                "Mon cheval",
                100,
                100
            }
        )

        TriggerClientEvent(
            "vorp:TipRight",
            _source,
            "🐴 Cheval acheté et sauvegardé !",
            4000
        )
    end)
end)
