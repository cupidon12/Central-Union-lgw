RegisterServerEvent("vorp_ecuries:groomHorse")
AddEventHandler("vorp_ecuries:groomHorse", function()
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        exports.oxmysql:update(
            "UPDATE player_horses SET last_groomed = NOW() WHERE charidentifier = ? AND is_default = 1",
            { Character.charIdentifier }
        )

        TriggerClientEvent("vorp_ecuries:groomHorseClient", _source)
    end)
end)
