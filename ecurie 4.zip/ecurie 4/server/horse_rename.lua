RegisterServerEvent("vorp_ecuries:renameHorse")
AddEventHandler("vorp_ecuries:renameHorse", function(horseId, newName)
    local _source = source

    if not newName or newName == "" then return end
    if #newName > 25 then newName = string.sub(newName, 1, 25) end

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        exports.oxmysql:update(
            "UPDATE player_horses SET name = ? WHERE id = ? AND charidentifier = ?",
            { newName, horseId, Character.charIdentifier }
        )

        TriggerClientEvent("vorp:TipRight", _source, "?? Cheval renomm�", 4000)
        TriggerClientEvent("vorp_ecuries:horseRenamed", _source)
    end)
end)
