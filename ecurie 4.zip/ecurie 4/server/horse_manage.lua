RegisterNetEvent("vorp_ecuries:getMyHorses")
AddEventHandler("vorp_ecuries:getMyHorses", function()
    local src = source
    local User = VORPcore.getUser(src)
    if not User then return end

    local Character = User.getUsedCharacter

    exports.oxmysql:execute(
        "SELECT id, name, model, is_default FROM player_horses WHERE identifier = ?",
        { Character.identifier },
        function(result)
            TriggerClientEvent("vorp_ecuries:sendMyHorses", src, result)
        end
    )
end)


RegisterNetEvent("vorp_ecuries:sellHorse")
AddEventHandler("vorp_ecuries:sellHorse", function(horseId, price)
    local src = source
    local User = VORPcore.getUser(src)
    if not User then return end

    local Character = User.getUsedCharacter
    local refund = math.floor(price * 0.5)

    exports.oxmysql:execute(
        "DELETE FROM player_horses WHERE id = ? AND identifier = ?",
        { horseId, Character.identifier }
    )

    Character.addCurrency(0, refund)
    TriggerClientEvent("vorp:TipRight", src, "Cheval vendu pour $" .. refund, 3000)
end)

RegisterNetEvent("vorp_ecuries:transferHorse")
AddEventHandler("vorp_ecuries:transferHorse", function(horseId, targetId)
    local src = source
    local User = VORPcore.getUser(src)
    if not User then return end

    local Target = VORPcore.getUser(tonumber(targetId))
    if not Target then
        TriggerClientEvent("vorp:TipRight", src, "Joueur introuvable", 3000)
        return
    end

    local Character = User.getUsedCharacter
    local TargetChar = Target.getUsedCharacter

    exports.oxmysql:execute(
        "UPDATE player_horses SET identifier = ? WHERE id = ? AND identifier = ?",
        { TargetChar.identifier, horseId, Character.identifier }
    )

    TriggerClientEvent("vorp:TipRight", src, "Cheval c�d�", 3000)
    TriggerClientEvent("vorp:TipRight", targetId, "Vous avez re�u un cheval", 3000)
end)


