RegisterNetEvent("vorp_ecuries:getBuyHorses")
AddEventHandler("vorp_ecuries:getBuyHorses", function()
    local src = source
    local races = {}

    for raceName, data in pairs(HorseInfo) do
        table.insert(races, {
            race = raceName,
            handling = data.handling,
            variations = data.variations
        })
    end

    TriggerClientEvent("vorp_ecuries:openBuyMenu", src, races)
end)
