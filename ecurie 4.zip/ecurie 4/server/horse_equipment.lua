--------------------------------------------------
-- HORSE_EQUIPMENT.LUA — SYSTÈME ÉQUIPEMENT (VORP)
-- LOGIQUE IDENTIQUE À VORP-STABLES
--------------------------------------------------

-- ======================
-- DEBUG CHARGEMENT
-- ======================
CreateThread(function()
    print("^2[VORP_ECURIES] horse_equipment.lua chargé^0")
end)

--------------------------------------------------
-- FONCTION INTERNE (SET TACK)
--------------------------------------------------
local function SetHorseTack(src, horseId, tackHash, price)
    TriggerEvent("vorp:getCharacter", src, function(Character)
        if not Character then return end
        if not horseId or not tackHash then return end

        -- Paiement
        if price and price > 0 then
            if Character.money < price then
                TriggerClientEvent("vorp:TipRight", src, "❌ Pas assez d'argent", 4000)
                return
            end
            Character.removeCurrency(0, price)
        end

        -- Charger équipement existant
        local result = exports.oxmysql:executeSync(
            "SELECT equipment FROM player_horses WHERE id = ? AND charidentifier = ? LIMIT 1",
            { horseId, Character.charIdentifier }
        )

        local equipment = {}
        if result and result[1] and result[1].equipment and result[1].equipment ~= "" then
            equipment = json.decode(result[1].equipment)
        end

        -- 🔥 VORP-STABLES : UN SEUL CHAMP
        equipment.tack = tackHash

        -- Sauvegarde BDD
        exports.oxmysql:update(
            "UPDATE player_horses SET equipment = ? WHERE id = ? AND charidentifier = ?",
            { json.encode(equipment), horseId, Character.charIdentifier }
        )

        TriggerClientEvent(
            "vorp:TipRight",
            src,
            "🐴 Selle équipée",
            3000
        )
    end)
end

--------------------------------------------------
-- EVENT CLIENT → SERVEUR
--------------------------------------------------
RegisterServerEvent("vorp_ecuries:setHorseTack")
AddEventHandler("vorp_ecuries:setHorseTack", function(horseId, tackHash, price)
    SetHorseTack(source, horseId, tackHash, price)
end)

--------------------------------------------------
-- COMMANDE DE TEST (TEMPORAIRE)
--------------------------------------------------
RegisterCommand("testhorsegear", function(source)
    TriggerEvent("vorp:getCharacter", source, function(Character)
        if not Character then return end

        local horse = exports.oxmysql:executeSync(
            "SELECT id FROM player_horses WHERE charidentifier = ? LIMIT 1",
            { Character.charIdentifier }
        )

        if not horse or not horse[1] then
            TriggerClientEvent("vorp:TipRight", source, "❌ Aucun cheval trouvé", 4000)
            return
        end

        -- 🐴 Selle western (TACK COMPLET)
        SetHorseTack(
            source,
            horse[1].id,
            0xBAA7E618, -- tack hash
            0
        )
    end)
end, false)
