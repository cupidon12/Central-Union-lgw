--------------------------------------------------
-- HORSE_UI.LUA � PONT ENTRE UI ET SERVEUR
--------------------------------------------------

RegisterServerEvent("vorp_ecuries:requestMyHorsesForUI")
AddEventHandler("vorp_ecuries:requestMyHorsesForUI", function()
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        -- r�cup�rer tous les chevaux du joueur
        local horses = exports.oxmysql:executeSync(
            "SELECT id, model, name, is_default FROM player_horses WHERE charidentifier = ?",
            { Character.charIdentifier }
        )

        -- envoyer les chevaux au menu UI
        TriggerClientEvent("vorp_ecuries:openStableUI", _source, horses)
    end)
end)
