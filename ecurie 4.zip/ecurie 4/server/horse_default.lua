RegisterServerEvent("vorp_ecuries:setDefaultHorse")
AddEventHandler("vorp_ecuries:setDefaultHorse", function(horseId)
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        -- retirer ancien cheval par d�faut
        exports.oxmysql:update(
            "UPDATE player_horses SET is_default = 0 WHERE charidentifier = ?",
            { Character.charIdentifier }
        )

        -- d�finir le nouveau
        exports.oxmysql:update(
            "UPDATE player_horses SET is_default = 1 WHERE id = ? AND charidentifier = ?",
            { horseId, Character.charIdentifier }
        )

        TriggerClientEvent(
            "vorp:TipRight",
            _source,
            "?? Cheval par d�faut d�fini",
            4000
        )
    end)
end)
