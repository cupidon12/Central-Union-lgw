--------------------------------------------------
-- HORSE_SPAWN.LUA — CHEVAL PAR DÉFAUT UNIQUEMENT
--------------------------------------------------

RegisterServerEvent("vorp_ecuries:setDefaultHorse")
AddEventHandler("vorp_ecuries:setDefaultHorse", function(horseId)
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        -- reset anciens chevaux par défaut
        exports.oxmysql:update(
            "UPDATE player_horses SET is_default = 0 WHERE charidentifier = ?",
            { Character.charIdentifier }
        )

        -- définir nouveau cheval par défaut
        exports.oxmysql:update(
            "UPDATE player_horses SET is_default = 1 WHERE id = ? AND charidentifier = ?",
            { horseId, Character.charIdentifier }
        )

        TriggerClientEvent("vorp:TipRight", _source, "⭐ Cheval par défaut défini", 4000)
    end)
end)

--------------------------------------------------
-- APPEL DU CHEVAL PAR DÉFAUT
--------------------------------------------------
RegisterServerEvent("vorp_ecuries:requestDefaultHorse")
AddEventHandler("vorp_ecuries:requestDefaultHorse", function()
    local _source = source

    TriggerEvent("vorp:getCharacter", _source, function(Character)
        if not Character then return end

        local horse = exports.oxmysql:executeSync(
            "SELECT * FROM player_horses WHERE charidentifier = ? AND is_default = 1 LIMIT 1",
            { Character.charIdentifier }
        )

        if not horse or not horse[1] then
            TriggerClientEvent("vorp:TipRight", _source, "❌ Aucun cheval actif", 4000)
            return
        end

        TriggerClientEvent("vorp_ecuries:spawnHorseClient", _source, horse[1])
    end)
end)
